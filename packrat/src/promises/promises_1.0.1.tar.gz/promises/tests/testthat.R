library(testthat)
library(promises)

test_check("promises")
