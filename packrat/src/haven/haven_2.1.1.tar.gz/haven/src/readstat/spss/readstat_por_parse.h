//
//  readstat_por_parse.h
//

ssize_t readstat_por_parse_double(const char *data, size_t len, double *result, 
        readstat_error_handler error_cb, void *user_ctx);
