
void *readstat_malloc(size_t size);
void *readstat_calloc(size_t count, size_t size);
void *readstat_realloc(void *ptr, size_t len);
